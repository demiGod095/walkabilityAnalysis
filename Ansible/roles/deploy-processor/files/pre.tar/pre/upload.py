import couchdb
import json

# with open('couchdb.txt','r') as f:
with open('/home/ec2-user/couchdb.txt','r') as db:
	content = db.read().split()
	host = content[0]
	user = content[1]
	passw = content[2]
	port = 5984

url = 'http://'+user+':'+passw+'@'+host+':'+str(port)+'/'

couch = couchdb.Server(url)

db = couch.create('web-sa2-zscore')
db = couch['web-sa2-zscore']
# with open('SA2ZScore.json') as f:
with open('/home/ec2-user/pre/SA2ZScore.json') as f:
	data = json.load(f)
	db.save({'_id': 'data', 'data': data})

db = couch.create('web-sa3-zscore')
db = couch['web-sa3-zscore']
# with open('SA3ZScore.json') as f:
with open('/home/ec2-user/pre/SA3ZScore.json') as f:
	data = json.load(f)
	db.save({'_id': 'data', 'data': data})

db = couch.create('web-sa4-zscore')
db = couch['web-sa4-zscore']
# with open('SA4ZScore.json') as f:
with open('/home/ec2-user/pre/SA4ZScore.json') as f:
	data = json.load(f)
	db.save({'_id': 'data', 'data': data})

#ZResult_obese_park_analysis
db = couch.create('web-zresult-obese-park')
db = couch['web-zresult-obese-park']
# with open('ZResult_obese_park_analysis.json') as f:
with open('/home/ec2-user/pre/ZResult_obese_park_analysis.json') as f:
	data = json.load(f)
	db.save({'_id': 'data', 'data': data})

db = couch.create('web-zresult-rest')
db = couch['web-zresult-rest']
# with open('ZResult_rest_analysis.json') as f:
with open('/home/ec2-user/pre/ZResult_rest_analysis.json') as f:
	data = json.load(f)
	db.save({'_id': 'data', 'data': data})

db = couch.create('web-result-obese')
db = couch['web-result-obese']
# with open('SA2_obesity.json') as f:
with open('/home/ec2-user/pre/SA2_obesity.json') as f:
	data = json.load(f)
	db.save({'_id': 'data', 'data': data})
